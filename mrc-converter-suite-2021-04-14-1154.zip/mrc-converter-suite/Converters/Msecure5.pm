# mSecure 5 CSV export converter
#
# Copyright 2018 Mike Cappella (mike@cappella.us)

package Converters::Msecure5;

our @ISA 	= qw(Exporter);
our @EXPORT     = qw(do_init do_import do_export);
our @EXPORT_OK  = qw();

use v5.14;
use utf8;
use strict;
use warnings;
#use diagnostics;

binmode STDOUT, ":utf8";
binmode STDERR, ":utf8";

use Utils::PIF;
use Utils::Utils;
use Utils::File;
use Utils::Normalize;
use IO::String;
use Time::Piece;

# Force lib included CSV_PP for consistency
BEGIN { $ENV{PERL_TEXT_CSV}='Text::CSV_PP'; }
use Text::CSV qw/csv/;

=pod

=encoding utf8

=head1 mSecure 5 converter module

=head2 Platforms

=over

=item B<macOS>: 5.x (see Notes)

=item B<Windows>: Untested

=back

=head2 Description

Converts your exported mSecure 5 data to 1PIF for 1Password import.
If you need to convert from mSecure prior to version 5, use the B<msecure> converter.

=head2 Instructions

Launch mSecure 5.

Launch mSecure, and export its database as a CSV export file using the C<< File > Export > CSV File... >> menu item.
Click C<OK> to the warning dialog that advises caution since your data will be exported in an unencrypted format.
Navigate to your B<Desktop> folder in the C<Export File> dialog, and in the C<File name> area, enter the name B<pm_export.txt>.
Click C<Save>.

You may now quit mSecure.

=head2 Notes

The mSecure 5 export format and features of mSecure 5 have changed dramatically from previous versions.
mSecure 5 eliminated older, infrequently used Types, and changed the names of some common Types.
It is not yet clear how user data imported into mSecure 5 from older mSecure vaults is handled.
Your feedback is appreciated.

Before you uninstall mSecure, be sure to examine your mSecure records for the follow issues, and resolve them as necessary:

The mSecure 5 CSV export does not contain field labels.
Verify that you understand the I<meaning> of the fields after you import into 1Password.
Take a screenshot or write down your mSecure field names, and order of your customized fields and cards, and compare
these against the data imported into 1Password.

The CSV export from mSecure 5 on Windows does not export custom fields.
Check your mSecure data for any custom fields.
The data exported to the CSV file does not contain this information, so you will have to manually transfer that data to your 
final 1Password entries.

The mSecure 5 CSV export sidesteps correctly encoding its CSV export.
It converts double-quotes into Unicode left B<“> and right B<”> quotes (Unicode 0x201c and 0x201d, respectively) for some fields.
This converter must reconvert these back to double-quotes and this, however, leaves the possibility that intentional
left and right Unicode quotes may get converted to ASCII double-quotes.
Also, mSecure 5 for Windows incorrectly encodes the two character sequence "\n" to the three character sequence "\\n".
The converter tries to compensate.

The mSecure 5 CSV export does not export attachments.
Check your mSecure data for records that contain attachments, and export these manually.

=cut

#
# The first four columns of mSecure's CSV are assumed and are always:
#	Group, Type, Description, Notes
#
# The number of per-type entries must match the number of columns for the type in mSecure CSV output.
#
# note: the second field, the type hint indicator (e.g. $card_field_specs{$type}[$i][1]}),
# is not used, but remains for code-consisency with other converter modules.
#
# mSecure 5 removes some categories and changes the names of some others.  It is not yet clear
# to me if users who upgrade will have both - may need to consolodate the msecure and msecure5 
# converters.  See the msecure converter for the original card_field_specs defs.
#
my %card_field_specs = (
    bankacct =>			{ textname => 'Bank Account', fields => [
	[ 'accountNo',		0, 'Account Number', ],
	[ 'telephonePin',	0, 'PIN', ],
	[ 'owner',		0, 'Name', ],
	[ 'branchAddress',	0, 'Branch', ],
	[ 'routingNo',		0, 'Routing Number', ],
	[ 'accountType',	0, 'Account Type', ],
	[ 'branchPhone',	0, 'Phone No.', ],
    ]},
    callingcards =>		{ textname => 'Calling Card', type_out => 'note', fields => [
	[ '_access_no',		0, 'Access No.', 	{ custfield => [ $Utils::PIF::sn_main, $Utils::PIF::k_string, 'access #' ] } ],
	[ '_pin',		0, 'PIN',		{ custfield => [ $Utils::PIF::sn_main, $Utils::PIF::k_concealed, 'pin', 'generate'=>'off' ] } ],
    ]},
    combination =>		{ textname => 'Combination', type_out => 'note', fields => [
	[ '_code',		0, 'Code', 		{ custfield => [ $Utils::PIF::sn_main, $Utils::PIF::k_concealed, 'code', 'generate'=>'off' ] } ],
    ]},
    creditcard =>		{ textname => 'Credit Card', fields => [
	[ 'ccnum',		0, 'Card No.', ],
	[ 'expiry',		0, 'Expiration Date', 		{ func => sub { return date2monthYear($_[0]) } } ],
	[ 'cvv',		0, 'Security Code', ],
	[ 'cardholder',		0, 'Name', ],
	[ 'pin',		0, 'PIN', ],
	[ 'bank',		0, 'Bank', ],
	[ 'phoneTollFree',	0, 'Phone Number', ],
	[ '_billingaddress',	0, 'Billing Address', ],
    ]},
    email =>			{ textname => 'Email Account', fields => [
	[ 'smtp_username',	0, 'Username', ],
	[ 'smtp_password',	0, 'Password', ],
	[ '_imap_server',	0, 'Incoming Mail Server', ],
	[ '_imap_port',		0, 'Incoming Port', ],
	[ 'smtp_server',	0, 'Outgoing mail Server', ],
	[ 'smtp_port',		0, 'Outgoing Port', ],
	[ 'pop_server',		0, 'POP3 Host', ],
	[ '_smtp_host',		0, 'SMTP Host', ],
    ]},
    frequentflyer =>		{ textname => 'Frequent Flyer', type_out => 'rewards', fields => [
	[ 'membership_no',	0, 'Number', ],
	[ 'website',		0, 'URL', ],
	[ 'member_name',	0, 'Username', ],
	[ 'pin',		0, 'Password', ],
	[ 'mileage',		0, 'Mileage', ],
    ]},
    insurance =>		{ textname => 'Insurance Info', type_out => 'membership', fields => [
	[ 'polid',		0, 'Policy No.',	{ custfield => [ $Utils::PIF::sn_main, $Utils::PIF::k_string, 'policy ID' ] } ],
	[ 'grpid',		0, 'Group No.',		{ custfield => [ $Utils::PIF::sn_main, $Utils::PIF::k_string, 'group ID' ] } ],
	[ 'insured',		0, 'Name',		{ custfield => [ $Utils::PIF::sn_main, $Utils::PIF::k_string, 'insured' ] } ],
	[ 'date',		0, 'Date', ],
	[ 'phone',		0, 'Phone No.', ],
    ]},
    login =>			{ textname => 'Login', fields => [
	[ 'url',		0, 'URL', ],
	[ 'username',		0, 'Username', ],
	[ 'password',		0, 'Password', ],
	[ '_empty1',		0, 'empty1', ],
	[ '_empty2',		0, 'empty2', ],
    ]},
    membership =>		{ textname => 'Membership', fields => [
	[ 'membership_no',	0, 'Account Number', ],
	[ 'member_name',	0, 'Name', ],
	[ 'member_since',	0, 'Start Date', 		{ func => sub { return date2monthYear($_[0]) }, keep => 1 } ],
	[ 'expiry_date',	0, 'Expiration Date', 		{ func => sub { return date2monthYear($_[0]) }, keep => 1 } ],
    ]},
    note =>			{ textname => 'Secure Note', fields => [
    ]},
);

$DB::single = 1;					# triggers breakpoint when debugging

sub do_init {
    return {
	'specs'		=> \%card_field_specs,
	'imptypes'  	=> qw/userdefined/,
	'opts'		=> [ 
	      		     [ q{      --sepchar <char>     # set the CSV separator character to char },
			       'sepchar=s' ],
	      		     [ q{      --dumpcats           # print the export's categories and field quantities },
			       'dumpcats' ],
			   ],
    }
}

sub do_import {
    my ($file, $imptypes) = @_;
    my $eol_seq = $^O eq 'MSWin32' ? "\x{5c}\x{6e}" : "\x{0b}";			# Win: backslash followed by n

    # Map localized card type strings to supported card type keys
    my %ll_typeMap;
    for (keys %card_field_specs) {
	$ll_typeMap{ll($card_field_specs{$_}{'textname'})} = $_;
    }

    my $sep_char = $main::opts{'sepchar'} // ',';

    length $sep_char == 1 or
	bail "The separator character should only be a single character - you've specified \"$sep_char\" which is ", length $sep_char, " characters.";

    # The mSecure/Windows CSV output is horribly broken
    my $csv = Text::CSV->new ({
	    binary => 1,
	    allow_loose_quotes => 1,
	    sep_char => $sep_char,
	    $^O eq 'MSWin32' ? ( eol => "\x{a}" ) : ( eol => "\x{a}"  )
    });

    my $data = slurp_file($file, 'utf8');

    # macOS mSecure export record line endings are 0a.
    # But the 0d 0b embedded newline endings within notes causes csv->getline() to
    # misdetect record boundaries.  Replace these now, and patch later.
    if ($^O eq 'darwin') {
        $data =~ s/\x{0d}\x{0b}/\x{01}/gs;      # 0d 0b         --> 01
    }

    my $io = IO::String->new($data);

    my (%Cards, %cat_field_tally);
    my ($n, $rownum) = (1, 1);

    while (my $row = $csv->getline ($io)) {
	if ($row->[0] eq '' and @$row == 1) {
	    warn "Skipping unexpected empty row: $n";
	    next;
	}
	next if @$row == 1 and $row->[0] eq 'mSecure CSV export file';

	pop @$row	if $^O eq 'darwin';	# ditch empty last column

	@$row >= 4 or
	    bail 'Only detected ', scalar @$row, pluralize(' column', scalar @$row), " in row $rownum.\n",
	    "The CSV separator \"$sep_char\" may be incorrect (use --sepchar), or perhaps you've edited the CSV mSecure export?";

	debug sprintf "ROW %d (%d cols): %s", $rownum++, scalar @$row, $row->[2];

	my ($itype, $otype, %cmeta, @fieldlist);

	# on Windows, need to convert \" into "
	if ($^O eq 'MSWin32') {
	    for (@$row) {
		#if (/\\"/) {
		#    say 'HIT \\\" to \" code: ', "'$_': ", hexdump($_);
		#    #s/\\"/"/g;
		#}
		if (/(?<!\\)\\n/) {
		    debug 'HIT \\n to <CR> code: ', "'$_': ", hexdump($_);
		    s/(?<!\\)\\n/\n/g;
		    debug 'Now                : ', "'$_': ", hexdump($_);
		}

		if (/\\\\n/) {
		    debug 'HIT \\\n to \n code: ', "'$_': ", hexdump($_);
		    s/\\\\n/\\n/g;
		    debug 'Now                : ', "'$_': ", hexdump($_);
		}
	    }
	}

	# mSecure CSV field order
	#
	#    group, cardtype, description, notes, ...
	#
	# The number of columns in each row varies by mSecure cardtype.  The %card_field_specs table
	# defines the meaning of each column per cardtype.  Some cardtypes will be remapped to 1P4
	# types.
	#
	push @{$cmeta{'tags'}}, shift @$row;
	my $msecure_type = shift @$row;
	$cmeta{'title'}	 = shift @$row;
	my $notes	 = shift @$row;

	if ($main::opts{'dumpcats'}) {
	    $cat_field_tally{$msecure_type}{scalar @$row}++;
	    next;
	}

	my @notes_list = ([], [], []);
	push @{$notes_list[2]},	$notes	 if $notes ne '';

	$cmeta{'folder'} = [ $cmeta{'tags'}[0] ];
	push @{$cmeta{'tags'}}, join '::', 'mSecure', $msecure_type;

	# When a user redefines an mSecure type, the card type and the field meanings are unknown.
	# In this case (the type isn't available in %ll_typeMap), force the card type to 'note' and push
	# to notes the values with generic labels prepended.
	#
	if (! exists $ll_typeMap{$msecure_type}) {
	    # skip 'userdefined' type not specifically included in a supplied import types list
	    next if defined $imptypes and (! exists $imptypes->{'userdefined'});

	    debug "Non-default type: '$msecure_type' mapped to Secure Notes\n";
	    $itype = $otype = 'note';
	    #push @{$notes_list[0]}, join ': ', ll('Type'), $msecure_type;
	    my $i;
	    while (@$row) {
		my ($key, $val) = ('Field_' . $i++, shift @$row);
		debug "\tfield: $key => ", $val;
		push @{$notes_list[1]}, join ': ', $key, $val;
	    }
	}
	else {
	    $itype = $ll_typeMap{$msecure_type};
	    $otype = $card_field_specs{$itype}{'type_out'} // $itype;
	    $cmeta{'title'} = join ': ', $msecure_type, $cmeta{'title'}		if $itype ne $otype;

	    # skip all types not specifically included in a supplied import types list
	    next if defined $imptypes and (! exists $imptypes->{$itype});

	    # process stock field columns beyond column 4 (notes)
	    for my $cfs (@{$card_field_specs{$itype}{'fields'}}) {
		my $val = shift @$row;

		next if not defined $val or $val eq '';

		# mSecure 5 replaces simple ASCII double quotes in some fields with unicode right and left quotes
		# during entry or upon export to CSV.
		$val =~ s/\x{201C}|\x{201D}/"/g;

		debug "\tfield: $cfs->[CFS_MATCHSTR] => $val";
		push @fieldlist, [ $cfs->[CFS_MATCHSTR] => $val ];
	    }
	}

	while (@$row) {
	    my ($label, $val);
	    if ($^O eq 'darwin') {
		$label = shift @$row;
	    }
	    else {
		$label = 'xxx';
	    }
	    $val = shift @$row;
	    debug "\tcust field: $label => $val";
	    push @fieldlist, [ $label => $val ];
	}

	# a few cleanups and flatten notes
	if ($^O ne 'MSWin32') {
	    s/\Q$eol_seq\E/\n/g	for @{$notes_list[2]};
	}
	$cmeta{'notes'} = myjoin "\n\n", map { myjoin "\n", @$_ } @notes_list;

	$cmeta{'notes'} =~ s/\x{01}/\x{0d}/g;			# restore embedded newlines
	$cmeta{'notes'} =~ s/\x{201C}|\x{201D}/"/g;		# replace unicode left and right quotes

	# special treatment for identity address ('address' is a $k_address type}
	if ($otype eq 'identity') {
	    my %h;
	    # assumption: fields are at $card_field_specs{'identity'}[5..10] and are in the following
	    # order: address address2 city state country zip
	    my $street_index = 5;
	    for (qw/street street2 city state country zip/) {
		$h{$_} = $fieldlist[$street_index++][1];
	    }
	    $h{'street'} = myjoin ', ', $h{'street'}, $h{'street2'};
	    delete $h{'street2'};
	    splice @fieldlist, 5, 6, [ Address => \%h ];
	}

	my $normalized = normalize_card_data(\%card_field_specs, $itype, \@fieldlist, \%cmeta);
	my $cardlist   = explode_normalized($itype, $normalized);

	for (keys %$cardlist) {
	    print_record($cardlist->{$_});
	    push @{$Cards{$_}}, $cardlist->{$_};
	}
	$n++;
    }
=cut
    if (+$csv->error_diag) {
    say "HERE WE ARE";
	$csv->error_diag;
	exit 1;
    }
=cut
    if (! $csv->eof()) {
	warn "Unexpected failure parsing CSV: row $n";
    }

    if ($main::opts{'dumpcats'}) {
	printf "%25s %10s   %s\n", 'Categories', 'Known?', 'Field Count(s)';
	for my $catname (sort keys %cat_field_tally) {
	    printf "%25s %8s         %s\n", $catname,
		    ( grep { $card_field_specs{$_}{'textname'} eq $catname  } keys %card_field_specs ) ? 'yes' : 'NO',
		    join(", ", map { $_ + 4 } keys %{$cat_field_tally{$catname}});
	}

	return undef;
    }

    summarize_import('item', $n - 1);
    return \%Cards;
}

sub do_export {
    add_custom_fields(\%card_field_specs);
    create_pif_file(@_);
}

# String localization.  mSecure has localized card types and field names, so these must be mapped
# to the localized versions in the Localizable.strings file for a given language.
# The %localized table will be initialized using the localized name as the key, and the english version
# as the value.
#
# Version 5 appear to not ship with languges files, so lets look in our local Languages directory.
#
my %localized;

sub init_localization_table {
    my $lang = shift;
    main::Usage(1, "Unknown language type: '$lang'")
	unless defined $lang and $lang =~ /^(de|es|fr|it|ja|ko|pl|pt|ru|zh-Hans|zh-Hant)$/;

    if ($lang) {
	my $lstrings_base = 'XX.lproj/Localizable.strings';
	$lstrings_base =~ s/XX/$lang/;
	my $lstrings_path = join '/', '/Applications/mSecure.app/Contents/Resources', $lstrings_base;
	if (! -e $lstrings_path) {
	    $lstrings_path = join '/', 'Languages/mSecure', $lstrings_base;
	}

	local $/ = "\r\n";
	open my $lfh, "<:encoding(utf16)", $lstrings_path
	    or bail "Unable to open localization strings file: $lstrings_path\n$!";
	while (<$lfh>) {
	    chomp;
	    my ($key, $val) = split /" = "/;
	    $key =~ s/^"//;
	    $val =~ s/";$//;
	    #say "Key: $key, Val: $val";
	    $localized{$key} = $val;
	}
    }
    1;
}

# Lookup the localized string and return its english string value.
sub ll {
    local $_ = shift;
    return $localized{$_} // $_;
}

# mm/yyyy
# mm/dd/yyyy
sub parse_date_string {
    local $_ = $_[0];

    if (/^(\d{2})\/(\d{4})$/) {
	if (my $t = Time::Piece->strptime($_, "%m/%Y")) {
	    return $t;
	}
    }
    elsif (/^(\d{2})\/(\d{2})\/(\d{4})$/) {
	if (my $t = Time::Piece->strptime($_, "%m/%d/%Y")) {
	    return $t;
	}
    }

    return undef;
}

sub date2monthYear {
    my $t = parse_date_string @_;

    return defined $t->year ? sprintf("%d%02d", $t->year, $t->mon) : $_[0];
}

1;
